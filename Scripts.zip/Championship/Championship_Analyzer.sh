#!/bin/bash

#Apostolos Georgas

touch Play2Win_Statistics.txt

cp Results/Total_Results.txt .

Play2Win_Championships=$(cat Total_Results.txt | grep "==== Champion is: Play2Win" | wc -l)
echo "Play2Win Championships: $Play2Win_Championships"  >> Play2Win_Statistics.txt
echo ""  >> Play2Win_Statistics.txt

echo "Play2Win Total Wins:"  >> Play2Win_Statistics.txt
cat Total_Results.txt | grep "Winner is: Play2Win_" | awk '{print $6}' >> Play2Win_Statistics.txt
cat Total_Results.txt | grep "==== Champion is: Play2Win" | awk '{print $7}' >> Play2Win_Statistics.txt
echo ""  >> Play2Win_Statistics.txt

echo "Play2Win Wins from White Neuronics:"  >> Play2Win_Statistics.txt
cat Total_Results.txt | grep "R16: Summary (Winner - Ratio - White wins - Black wins):" | grep Play2Win_ | awk '{print $16}' >> Play2Win_Statistics.txt
cat Total_Results.txt | grep "R8: Summary (Winner - Ratio - White wins - Black wins):" | grep Play2Win_ | awk '{print $16}' >> Play2Win_Statistics.txt
cat Total_Results.txt | grep "Semi-Final: Summary (Winner - Ratio - White wins - Black wins):" | grep Play2Win_ | awk '{print $16}' >> Play2Win_Statistics.txt
cat Total_Results.txt | grep "Grand Final: Summary (Winner - Ratio - White wins - Black wins):" | grep Play2Win_ | awk '{print $17}' >> Play2Win_Statistics.txt
echo ""  >> Play2Win_Statistics.txt

echo "Play2Win Wins from Black Neuronics:"  >> Play2Win_Statistics.txt
cat Total_Results.txt | grep "R16: Summary (Winner - Ratio - White wins - Black wins):" | grep Play2Win_ | awk '{print $18}' >> Play2Win_Statistics.txt
cat Total_Results.txt | grep "R8: Summary (Winner - Ratio - White wins - Black wins):" | grep Play2Win_ | awk '{print $18}' >> Play2Win_Statistics.txt
cat Total_Results.txt | grep "Semi-Final: Summary (Winner - Ratio - White wins - Black wins):" | grep Play2Win_ | awk '{print $18}' >> Play2Win_Statistics.txt
cat Total_Results.txt | grep "Grand Final: Summary (Winner - Ratio - White wins - Black wins):" | grep Play2Win_ | awk '{print $19}' >> Play2Win_Statistics.txt
echo ""  >> Play2Win_Statistics.txt


echo "Play2Win Average Advantage Ratio:"  >> Play2Win_Statistics.txt
cat Total_Results.txt | grep "Championship summary (Champion - Average Ratio): Play2Win" | awk '{print $9}' >> Play2Win_Statistics.txt

touch Play2Teach_Statistics.txt

Play2Teach_Championships=$(cat Total_Results.txt | grep "==== Champion is: Play2Teach" | wc -l)
echo "Play2Teach Championships: $Play2Teach_Championships"  >> Play2Teach_Statistics.txt
echo ""  >> Play2Teach_Statistics.txt

echo "Play2Teach Total Wins:"  >> Play2Teach_Statistics.txt
cat Total_Results.txt | grep "Winner is: Play2Teach_" | awk '{print $6}' >> Play2Teach_Statistics.txt
cat Total_Results.txt | grep "==== Champion is: Play2Teach" | awk '{print $7}' >> Play2Teach_Statistics.txt
echo ""  >> Play2Teach_Statistics.txt

echo "Play2Teach Wins from White Neuronics:"  >> Play2Teach_Statistics.txt
cat Total_Results.txt | grep "R16: Summary (Winner - Ratio - White wins - Black wins):" | grep Play2Teach_ | awk '{print $16}' >> Play2Teach_Statistics.txt
cat Total_Results.txt | grep "R8: Summary (Winner - Ratio - White wins - Black wins):" | grep Play2Teach_ | awk '{print $16}' >> Play2Teach_Statistics.txt
cat Total_Results.txt | grep "Semi-Final: Summary (Winner - Ratio - White wins - Black wins):" | grep Play2Teach_ | awk '{print $16}' >> Play2Teach_Statistics.txt
cat Total_Results.txt | grep "Grand Final: Summary (Winner - Ratio - White wins - Black wins):" | grep Play2Teach_ | awk '{print $17}' >> Play2Teach_Statistics.txt
echo ""  >> Play2Teach_Statistics.txt

echo "Play2Teach Wins from Black Neuronics:"  >> Play2Teach_Statistics.txt
cat Total_Results.txt | grep "R16: Summary (Winner - Ratio - White wins - Black wins):" | grep Play2Teach_ | awk '{print $18}' >> Play2Teach_Statistics.txt
cat Total_Results.txt | grep "R8: Summary (Winner - Ratio - White wins - Black wins):" | grep Play2Teach_ | awk '{print $18}' >> Play2Teach_Statistics.txt
cat Total_Results.txt | grep "Semi-Final: Summary (Winner - Ratio - White wins - Black wins):" | grep Play2Teach_ | awk '{print $18}' >> Play2Teach_Statistics.txt
cat Total_Results.txt | grep "Grand Final: Summary (Winner - Ratio - White wins - Black wins):" | grep Play2Teach_ | awk '{print $19}' >> Play2Teach_Statistics.txt
echo ""  >> Play2Teach_Statistics.txt

echo "Play2Teach Average Advantage Ratio:"  >> Play2Teach_Statistics.txt
cat Total_Results.txt | grep "Championship summary (Champion - Average Ratio): Play2Teach" | awk '{print $9}' >> Play2Teach_Statistics.txt

rm Total_Results.txt
