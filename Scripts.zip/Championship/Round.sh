#!/bin/bash

#Apostolos Georgas

mkdir Neuronics-IN
mkdir Neuronics-OUT
mv Neuronics-IN.zip Neuronics-IN
cd Neuronics-IN
unzip -q Neuronics-IN.zip
cp RLGameCC.jar ../Neuronics-OUT
rm Neuronics-IN.zip

num=$(find -type d | wc -l) #count the folders = number of players

let "num -= 1" #exclude the "upper" directory

final=2

if [[ "$num" -gt "$final" ]]; then

	echo "============================================"
	echo "====== The Round of " $num " is starting!======="	
	echo "============================================"

else

	echo "========================================="
	echo "====== The Grand Final is starting!======"
	echo "========================================="
	
fi

i=0
k=0

while [ $i -lt $num ]
do
  
  
wins_A=0
wins_B=0

mkdir Player_A
mkdir Player_B
mkdir WhitePlayer_A_BlackPlayer_B
mkdir WhitePlayer_B_BlackPlayer_A

mv Player_$i/whVWeights Player_A
mv Player_$i/whWWeights Player_A
mv Player_$i/blVWeights Player_A
mv Player_$i/blWWeights Player_A
mv Player_$i/Play2* Player_A

rm -rf Player_$i

mv Player_$(($i+1))/whVWeights  Player_B
mv Player_$(($i+1))/whWWeights  Player_B
mv Player_$(($i+1))/blVWeights  Player_B
mv Player_$(($i+1))/blWWeights  Player_B
mv Player_$(($i+1))/Play2* Player_B

rm -rf Player_$(($i+1))

cd Player_A

mv whVWeights ../WhitePlayer_A_BlackPlayer_B
mv whWWeights  ../WhitePlayer_A_BlackPlayer_B
mv blVWeights ../WhitePlayer_B_BlackPlayer_A
mv blWWeights  ../WhitePlayer_B_BlackPlayer_A

cp ../RLGameCC.jar ../WhitePlayer_A_BlackPlayer_B

cd ../Player_B

mv whVWeights ../WhitePlayer_B_BlackPlayer_A
mv whWWeights  ../WhitePlayer_B_BlackPlayer_A
mv blVWeights ../WhitePlayer_A_BlackPlayer_B
mv blWWeights  ../WhitePlayer_A_BlackPlayer_B

cp ../RLGameCC.jar ../WhitePlayer_B_BlackPlayer_A


cd ../WhitePlayer_A_BlackPlayer_B

java -jar RLGameCC.jar $1 > match_stats.txt

wins_AA=$(more *stats.txt | grep aspros | wc -l)
wins_BB=$(more *stats.txt | grep mavros | wc -l)

cd ../WhitePlayer_B_BlackPlayer_A

java -jar RLGameCC.jar $1 > match_stats.txt

wins_BA=$(more *stats.txt | grep aspros | wc -l)
wins_AB=$(more *stats.txt | grep mavros | wc -l)

let wins_B=wins_BB+wins_BA
let wins_A=wins_AA+wins_AB

cd ..

if [[ "$wins_A" -ge "$wins_B" ]]; then

	mkdir ../Neuronics-OUT/Player_$k
	
	cd Player_B

	Looser=$(ls -la | grep Play2 | awk '{print $9}')
	
	cd ..
	
	cd Player_A

	Winner=$(ls -la | grep Play2 | awk '{print $9}')

	advantage_ratio=$(echo $wins_A/$wins_B | bc -l)
	
	echo "== Game $k: $Winner vs $Looser ====="
	echo "==== Winner is: $Winner with $wins_A wins! ==="
	echo "==== $wins_AA wins from his White neuronics ======="
	echo "==== $wins_AB wins from his Black neuronics ======="
    echo "Advantage ratio for the winner: $advantage_ratio"
	echo "============================================="
	
	mv Play2* ../../Neuronics-OUT/Player_$k
	
	cd ..
	
    mv WhitePlayer_A_BlackPlayer_B/whVWeights ../Neuronics-OUT/Player_$k
	mv WhitePlayer_A_BlackPlayer_B/whWWeights ../Neuronics-OUT/Player_$k
	mv WhitePlayer_B_BlackPlayer_A/blVWeights ../Neuronics-OUT/Player_$k
	mv WhitePlayer_B_BlackPlayer_A/blWWeights ../Neuronics-OUT/Player_$k
	

else

	mkdir ../Neuronics-OUT/Player_$k

	cd Player_A

	Looser=$(ls -la | grep Play2 | awk '{print $9}')
	
	cd ..
	
	cd Player_B

	Winner=$(ls -la | grep Play2 | awk '{print $9}')

	advantage_ratio=$(echo $wins_B/$wins_A | bc -l)
    
	echo "== Game $k: $Winner vs $Looser ====="
	echo "==== Winner is: $Winner with $wins_B wins! ==="
	echo "==== $wins_BA wins from his White neuronics ======="
	echo "==== $wins_BB wins from his Black neuronics ======="
	echo "Advantage ratio for the winner: $advantage_ratio"
	echo "============================================="
	
	mv Play2* ../../Neuronics-OUT/Player_$k
	
	cd ..
	
    mv WhitePlayer_B_BlackPlayer_A/whVWeights ../Neuronics-OUT/Player_$k
	mv WhitePlayer_B_BlackPlayer_A/whWWeights ../Neuronics-OUT/Player_$k
	mv WhitePlayer_A_BlackPlayer_B/blVWeights ../Neuronics-OUT/Player_$k
	mv WhitePlayer_A_BlackPlayer_B/blWWeights ../Neuronics-OUT/Player_$k
	
fi

rm -rf Player_A
rm -rf Player_B
rm -rf WhitePlayer_A_BlackPlayer_B
rm -rf WhitePlayer_B_BlackPlayer_A

 
let i=$(( $i + 2 ))
let k=$(( $k + 1 ))

 
done

cd ..

cd Neuronics-OUT

zip -q -r Neuronics-OUT.zip Player_* RLGameCC.jar

mv Neuronics-OUT.zip ../

cd ..

rm -rf Neuronics-OUT
rm -rf Neuronics-IN

echo "===== The round is finished succesfully! ====="
