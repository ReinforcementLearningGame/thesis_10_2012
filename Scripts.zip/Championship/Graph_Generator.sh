#!/bin/bash

#Apostolos Georgas

cp Results/Results_*.txt .

i=1
while [ $i -le $1 ]
do

	touch Graph_$i.gv

	echo "digraph Championship$i {"  >> Graph_$i.gv

	k=0
	while [ $k -lt 8 ]
	do
		
		let m=$(( $k + 1 ))
		
		Player_1=$(cat Results_$i.txt | grep "Game $k" | awk "NR==1{print;exit}" | awk '{print $4}') 
		Player_2=$(cat Results_$i.txt | grep "Game $k" | awk "NR==1{print;exit}" | awk '{print $6}')
		Winner=$(cat Results_$i.txt | grep "Winner is" | awk "NR==$m{print;exit}" | awk '{print $4}') 
		Ratio=$(cat Results_$i.txt | grep "Advantage ratio" | awk "NR==$m{print;exit}" | awk '{print $6}')
		Ratio=$(echo "scale=2; $Ratio / 1" | bc)
		
		if [ "$Winner" = "$Player_1" ]; then
		            
			echo "r8$Winner [shape=record, label = \"{$Player_1 | Ratio: $Ratio}\"]"  >> Graph_$i.gv
			echo "$Player_1 -> r8$Winner [style=bold color=green]" >> Graph_$i.gv
			echo "$Player_2 -> r8$Winner [style=dotted color=red]" >> Graph_$i.gv

		else
		
			echo "r8$Winner [shape=record, label = \"{$Player_2 | Ratio: $Ratio}\"]"  >> Graph_$i.gv
			echo "$Player_2 -> r8$Winner [style=bold color=green]" >> Graph_$i.gv
			echo "$Player_1 -> r8$Winner [style=dotted color=red]" >> Graph_$i.gv
	
		fi
		
		let k=$(( $k + 1 ))
		done


	k=0
	while [ $k -lt 4 ]
	do
		
		let m=$(( $m + 1 ))
		Player_1=$(cat Results_$i.txt | grep "Game $k" | awk "NR==2{print;exit}" | awk '{print $4}') 
		Player_2=$(cat Results_$i.txt | grep "Game $k" | awk "NR==2{print;exit}" | awk '{print $6}')
		Winner=$(cat Results_$i.txt | grep "Winner is" | awk "NR==$m{print;exit}" | awk '{print $4}') 
		Ratio=$(cat Results_$i.txt | grep "Advantage ratio" | awk "NR==$m{print;exit}" | awk '{print $6}')
		Ratio=$(echo "scale=2; $Ratio / 1" | bc)
		
		if [ "$Winner" = "$Player_1" ]; then
		            
			echo "r4$Winner [shape=record, label = \"{$Player_1 | Ratio: $Ratio}\"]"  >> Graph_$i.gv
			echo "r8$Player_1 -> r4$Winner [style=bold color=green]" >> Graph_$i.gv
			echo "r8$Player_2 -> r4$Winner [style=dotted color=red]" >> Graph_$i.gv

		else
		
			echo "r4$Winner [shape=record, label = \"{$Player_2 | Ratio: $Ratio}\"]"  >> Graph_$i.gv
			echo "r8$Player_2 -> r4$Winner [style=bold color=green]" >> Graph_$i.gv
			echo "r8$Player_1 -> r4$Winner [style=dotted color=red]" >> Graph_$i.gv
	
		fi
		
	let k=$(( $k + 1 ))
	done
		
	k=0
	while [ $k -lt 2 ]
	do
		
		let m=$(( $m + 1 ))
	
		Player_1=$(cat Results_$i.txt | grep "Game $k" | awk "NR==3{print;exit}" | awk '{print $4}') 
		Player_2=$(cat Results_$i.txt | grep "Game $k" | awk "NR==3{print;exit}" | awk '{print $6}')
		Winner=$(cat Results_$i.txt | grep "Winner is" | awk "NR==$m{print;exit}" | awk '{print $4}') 
		Ratio=$(cat Results_$i.txt | grep "Advantage ratio" | awk "NR==$m{print;exit}" | awk '{print $6}')
		Ratio=$(echo "scale=2; $Ratio / 1" | bc)
		
		if [ "$Winner" = "$Player_1" ]; then
		            
			echo "sm$Winner [shape=record, label = \"{$Player_1 | Ratio: $Ratio}\"]"  >> Graph_$i.gv
			echo "r4$Player_1 -> sm$Winner [style=bold color=green]" >> Graph_$i.gv
			echo "r4$Player_2 -> sm$Winner [style=dotted color=red]" >> Graph_$i.gv

		else
		
			echo "sm$Winner [shape=record, label = \"{$Player_2 | Ratio: $Ratio}\"]"  >> Graph_$i.gv
			echo "r4$Player_2 -> sm$Winner [style=bold color=green]" >> Graph_$i.gv
			echo "r4$Player_1 -> sm$Winner [style=dotted color=red]" >> Graph_$i.gv
	
		fi
		
	let k=$(( $k + 1 ))
	done

	let m=$(( $m + 1 ))
	k=0
	Player_1=$(cat Results_$i.txt | grep "Game $k" | awk "NR==4{print;exit}" | awk '{print $4}') 
	Player_2=$(cat Results_$i.txt | grep "Game $k" | awk "NR==4{print;exit}" | awk '{print $6}')
	Winner=$(cat Results_$i.txt | grep "Champion is" | awk "NR==1{print;exit}" | awk '{print $4}') 
	Ratio=$(cat Results_$i.txt | grep "Advantage ratio" | awk "NR==$m{print;exit}" | awk '{print $6}')
	Ratio=$(echo "scale=2; $Ratio / 1" | bc)
	Average_Ratio=$(cat Results_$i.txt | grep "Championship summary (Champion - Average Ratio)" | awk "NR==1{print;exit}" | awk '{print $9}') 
	Average_Ratio=$(echo "scale=2; $Average_Ratio / 1" | bc)
	
	if [ "$Winner" = "$Player_1" ]; then
		
		echo "Champion [shape=record, label = \"{Champion: $Player_1 | Ratio: $Ratio | AVG Ratio: $Average_Ratio}\" style=filled fillcolor =gold weight=3]"  >> Graph_$i.gv
		echo "sm$Player_1 -> Champion [style=bold color=green]" >> Graph_$i.gv
		echo "sm$Player_2 -> Champion [style=dotted color=red]" >> Graph_$i.gv

	else

		echo "Champion [shape=record, label = \"{Champion: $Player_2 | Ratio: $Ratio | AVG Ratio: $Average_Ratio}\" style=filled fillcolor =gold weight=3]"  >> Graph_$i.gv
		echo "sm$Player_2 -> Champion [style=bold color=green]" >> Graph_$i.gv
		echo "sm$Player_1 -> Champion [style=dotted color=red]" >> Graph_$i.gv
	
	fi

	
		
echo "}"  >> Graph_$i.gv
		
let i=$(( $i + 1 ))

done

mkdir Graphs
mv *.gv Graphs

rm Results_*.txt