#!/bin/bash

#Apostolos Georgas

touch Total_Results.txt

i=1
while [ $i -le $1 ]
do

	touch Results_$i.txt

	echo "============ Championship no. $i ===========" >> Results_$i.txt
	echo ""  >> Results_$i.txt
	echo "============ Round of 16 Results: =========" >> Results_$i.txt
	echo ""  >> Results_$i.txt

	cd Round16
	cd outputs
  
	cd $i
	cd 0

	k=1
	while [ $k -le 8 ]
	do
		cat stdout.log | grep "== Game" | awk "NR==$k{print;exit}" >> ../../../../Results_$i.txt
		cat stdout.log | grep "==== Winner is:" | awk "NR==$k{print;exit}" >> ../../../../Results_$i.txt
		Winner=`cat stdout.log | grep "==== Winner is:" | awk "NR==$k{print;exit}" | awk '{print $4}'`
		cat stdout.log | grep "wins from his White neuronics ===" | awk "NR==$k{print;exit}"  >> ../../../../Results_$i.txt
		White_Wins=$(cat stdout.log | grep "wins from his White neuronics ===" | awk "NR==$k{print;exit}"  | awk '{print $2}')
		cat stdout.log | grep "wins from his Black neuronics ==="  | awk "NR==$k{print;exit}" >> ../../../../Results_$i.txt
		Black_Wins=$(cat stdout.log | grep "wins from his Black neuronics ===" | awk "NR==$k{print;exit}"  | awk '{print $2}')
		cat stdout.log | grep "Advantage ratio for the winner" | awk "NR==$k{print;exit}" >> ../../../../Results_$i.txt
		Ratio=`cat stdout.log | grep "Advantage ratio for the winner" | awk "NR==$k{print;exit}" | awk '{print $6}'`
		Ratio=$(echo "scale=2; $Ratio / 1" | bc)
		echo "R16: Summary (Winner - Ratio - White wins - Black wins): $Winner - $Ratio - $White_Wins - $Black_Wins" >> ../../../../Results_$i.txt
		echo "" >> ../../../../Results_$i.txt
		let k=$(( $k + 1 ))
	done

	cd ../../../../
	echo ""  >> Results_$i.txt

	echo "============ Round of 8 Results: =========" >> Results_$i.txt
	echo ""  >> Results_$i.txt

	cd Round8
	cd outputs
  
	cd $i
	cd 0
	
	k=1
	while [ $k -le 4 ]
	do
		cat stdout.log | grep "== Game" | awk "NR==$k{print;exit}" >> ../../../../Results_$i.txt
		cat stdout.log | grep "==== Winner is:" | awk "NR==$k{print;exit}" >> ../../../../Results_$i.txt
		Winner=`cat stdout.log | grep "==== Winner is:" | awk "NR==$k{print;exit}" | awk '{print $4}'`
		cat stdout.log | grep "wins from his White neuronics ===" | awk "NR==$k{print;exit}"  >> ../../../../Results_$i.txt
		White_Wins=$(cat stdout.log | grep "wins from his White neuronics ===" | awk "NR==$k{print;exit}"  | awk '{print $2}')
		cat stdout.log | grep "wins from his Black neuronics ==="  | awk "NR==$k{print;exit}" >> ../../../../Results_$i.txt
		Black_Wins=$(cat stdout.log | grep "wins from his Black neuronics ===" | awk "NR==$k{print;exit}"  | awk '{print $2}')
		cat stdout.log | grep "Advantage ratio for the winner" | awk "NR==$k{print;exit}" >> ../../../../Results_$i.txt
		Ratio=`cat stdout.log | grep "Advantage ratio for the winner" | awk "NR==$k{print;exit}" | awk '{print $6}'`
		Ratio=$(echo "scale=2; $Ratio / 1" | bc)
		echo "R8: Summary (Winner - Ratio - White wins - Black wins): $Winner - $Ratio - $White_Wins - $Black_Wins" >> ../../../../Results_$i.txt
		echo "" >> ../../../../Results_$i.txt
		let k=$(( $k + 1 ))
	done

	cd ../../../../
	echo ""  >> Results_$i.txt

	echo "============ Semi Final Results: =========" >> Results_$i.txt
	echo ""  >> Results_$i.txt

	cd Semi-Final
	cd outputs
  
	cd $i
	cd 0

	k=1
	while [ $k -le 2 ]
	do
		cat stdout.log | grep "== Game" | awk "NR==$k{print;exit}" >> ../../../../Results_$i.txt
		cat stdout.log | grep "==== Winner is:" | awk "NR==$k{print;exit}" >> ../../../../Results_$i.txt
		Winner=`cat stdout.log | grep "==== Winner is:" | awk "NR==$k{print;exit}" | awk '{print $4}'`
		cat stdout.log | grep "wins from his White neuronics ===" | awk "NR==$k{print;exit}"  >> ../../../../Results_$i.txt
		White_Wins=$(cat stdout.log | grep "wins from his White neuronics ===" | awk "NR==$k{print;exit}"  | awk '{print $2}')
		cat stdout.log | grep "wins from his Black neuronics ==="  | awk "NR==$k{print;exit}" >> ../../../../Results_$i.txt
		Black_Wins=$(cat stdout.log | grep "wins from his Black neuronics ===" | awk "NR==$k{print;exit}"  | awk '{print $2}')
		cat stdout.log | grep "Advantage ratio for the winner" | awk "NR==$k{print;exit}" >> ../../../../Results_$i.txt
		Ratio=`cat stdout.log | grep "Advantage ratio for the winner" | awk "NR==$k{print;exit}" | awk '{print $6}'`
		Ratio=$(echo "scale=2; $Ratio / 1" | bc)
		echo "Semi-Final: Summary (Winner - Ratio - White wins - Black wins): $Winner - $Ratio - $White_Wins - $Black_Wins" >> ../../../../Results_$i.txt
		echo "" >> ../../../../Results_$i.txt
		let k=$(( $k + 1 ))
	done

	cd ../../../../	
	echo ""  >> Results_$i.txt

	echo "============ Grand Final Results: =========" >> Results_$i.txt
	echo ""  >> Results_$i.txt

	cd Final
	cd outputs
  
	cd $i
	cd 0
	cat stdout.log | grep "== Game" | awk "NR==1{print;exit}" >> ../../../../Results_$i.txt
	Champion=$( cat stdout.log | grep "==== Winner is:" | awk "NR==1{print;exit}" | awk '{print $4}')
	Wins=$( cat stdout.log | grep "==== Winner is:" | awk "NR==1{print;exit}" | awk '{print $6}')
	echo "==== Champion is: $Champion with total $Wins wins! ====" >> ../../../../Results_$i.txt
	cat stdout.log | grep "wins from his White neuronics ===" | awk "NR==1{print;exit}"  >> ../../../../Results_$i.txt
	White_Wins=$(cat stdout.log | grep "wins from his White neuronics ===" | awk "NR==1{print;exit}"  | awk '{print $2}')
	cat stdout.log | grep "wins from his Black neuronics ==="  | awk "NR==1{print;exit}" >> ../../../../Results_$i.txt
	Black_Wins=$(cat stdout.log | grep "wins from his Black neuronics ===" | awk "NR==1{print;exit}"  | awk '{print $2}')
	cat stdout.log | grep "Advantage ratio for the winner" | awk "NR==1{print;exit}" >> ../../../../Results_$i.txt
	Ratio=`cat stdout.log | grep "Advantage ratio for the winner" | awk "NR==1{print;exit}" | awk '{print $6}'`
	Ratio=$(echo "scale=2; $Ratio / 1" | bc)
	echo "Grand Final: Summary (Winner - Ratio - White wins - Black wins): $Champion - $Ratio - $White_Wins - $Black_Wins" >> ../../../../Results_$i.txt
	echo "" >> ../../../../Results_$i.txt	

	cd ../../../../

	Ratio_16=`more Results_$i.txt | grep "R16: Summary (Winner" | grep $Champion | awk '{print $14}'`
	Ratio_8=`more Results_$i.txt | grep "R8: Summary (Winner" | grep $Champion | awk '{print $14}'`
	Ratio_4=`more Results_$i.txt | grep "Semi-Final: Summary (Winner" | grep $Champion | awk '{print $14}'`
	Ratio_2=`more Results_$i.txt | grep "Grand Final: Summary (Winner" | awk '{print $15}'`

	Sum_Ratios=$(echo "scale=2; $Ratio_16 + $Ratio_8 + $Ratio_4 + $Ratio_2" | bc)

    Average_Ratio=$(echo "scale=2; $Sum_Ratios / 4" | bc)
	
	echo "Championship summary (Champion - Average Ratio): $Champion - $Average_Ratio" >> Results_$i.txt
	echo "" >> Results_$i.txt

	echo "===== Championship is finished succesfully ====="  >> Results_$i.txt
	echo ""  >> Results_$i.txt

let i=$(( $i + 1 ))
done

cat Results_* >> Total_Results.txt

mkdir Results

mv Results*.txt Results
mv Total_Results.txt Results

