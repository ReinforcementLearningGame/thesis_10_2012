#!/bin/bash

#Apostolos Georgas

#!/bin/bash

java -jar RLGameCC.jar $1

#tar cvzf WhiteMC1-BlackHuman-Resuls.tgz *Weights *stats.txt

tar cvzf WhiteMC1-BlackHuman-Stats.tgz *stats.txt

