#!/bin/bash

# history
# January 1, 2012: A. Georgas

#extract the neuronics from the parameter sweep port
echo "==== Start of workflow execution ====" 
date
echo "====================================="
ls -la
unzip *.zip
