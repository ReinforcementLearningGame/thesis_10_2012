#!/bin/bash

#Apostolos Georgas

#!/bin/bash

java -jar RLGameCC.jar $1

#tar cvzf BlackMC1-WhiteHuman-Results.tgz *Weights *stats.txt

tar cvzf BlackMC1-WhiteHuman-Stats.tgz *stats.txt





