#!/bin/bash

#Script to analyze the results from the job executions of RLGame

#Apostolos Georgas

#Initialization
max=1
winner=0


mkdir TotalStats

mv TotalStats*.* TotalStats

cd TotalStats

touch Results.txt

num_of_players=$(ls -la | grep TotalStats | wc -l) #count the files received from wrapper = number of workflow instances = number of players

echo "Number of Players: " $num_of_players


for (( i = 0; i < $num_of_players; i++ ))

do #Put every Player's statistics to separate folders
	
	mkdir Player_$i
	
	mv  TotalStats.tgz_$i Player_$i
	
	cd Player_$i
	
	mv  TotalStats.tgz_$i TotalStats.tgz
	
	tar -zxvf TotalStats.tgz
	
	rm TotalStats.tgz
	
	# keep only BlackMC1-WhiteHuman-Stats.tgz & WhiteMC1-BlackHuman-Stats.tgz
	find  -name "*.*" ! -name "*.tgz" -type f -exec rm {} \; 
	#alternatively: ls * | grep -v *.tgz | xargs rm -rf 
	
	#If you create a tar archive on system A and then try to unpack it on system B and system B's clock is behind that of system A then tar will complain.
    #If you use the -m switch to tar then it will set all of the modified times on the unpacked files to the current system time.
	
	echo "======= Player: $i =======" >> ../Results.txt

	tar -zxvmf BlackMC1-WhiteHuman-Stats.tgz
	
	mv *stats.txt WhiteNeuronics_$i.log
	
	human_white_wins=$(more WhiteNeuronics_$i.log | grep aspros | wc -l)

	echo "Player's wins with white neuronics: $human_white_wins"
	
	echo "Player's wins with white neuronics: $human_white_wins"  >> ../Results.txt
	
	tar -zxvmf WhiteMC1-BlackHuman-Stats.tgz
	
	mv *stats.txt BlackNeuronics_$i.log

	human_black_wins=$(more BlackNeuronics_$i.log | grep mavros | wc -l)

	echo "Player's wins with black neuronics: $human_black_wins"
	
	echo "Player's wins with black neuronics: $human_black_wins"  >> ../Results.txt

	let human_total_wins=$human_white_wins+$human_black_wins
	
	echo "Player's total wins: $human_total_wins" >> ../Results.txt

   if [[ "$human_total_wins" -gt "$max" ]]; then
       max="$human_total_wins"
	   winner=$i
   fi

    cd ..	

done

echo "" >> Results.txt
echo "Winner is Player $winner with total wins: $max !!!" >> Results.txt

echo "======= Analyzer finished sucessfully !!! ======="

#Move results file to the root directory to be fetched from the portal
mv Results.txt ../

cd ..

#Isolate data for analysis in MS Excel
more Results.txt | grep "Player's wins with white neuronics: " | awk '{print $6}' > White_Data.txt
more Results.txt | grep "Player's wins with black neuronics: " | awk '{print $6}' > Black_Data.txt

tar -cvf Results.tar Results.txt White_Data.txt Black_Data.txt

echo "==== End of workflow execution ====" 
date
echo "===================================="
