#!/bin/bash

#Apostolos Georgas

#!/bin/bash

tar cvzf TotalStats.tgz *.*



